All the results will be in ${-2^{31} \sim 2^{31}-1}$.

For Java users, the name of your class should be `Main`.